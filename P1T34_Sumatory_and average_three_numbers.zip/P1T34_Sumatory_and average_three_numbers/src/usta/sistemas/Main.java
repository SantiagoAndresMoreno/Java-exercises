package usta.sistemas;

import java.util.Scanner;
public class Main {
    //Author: Santiago Andres Moreno Sanchez
    //Date:12/03/2020
    //Description:This software realize of sumatory by three numbers and average them


    public static void main(String[] args) {
        Scanner keyboard=new Scanner(System.in);
        int v1, v2, v3 ,suma ;
        double Average;
        System.out.println("this program adds three variable, input them first variable");
        v1=keyboard.nextInt();
        System.out.println("Input the second variable");
        v2=keyboard.nextInt();
        System.out.println("Input the third variable");
        v3=keyboard.nextInt();
        suma= v1+v2+v3;
        Average = suma/3;
        System.out.println("The sumatory is: "+suma);
        System.out.println("The average is: "+Average);

    }
}
