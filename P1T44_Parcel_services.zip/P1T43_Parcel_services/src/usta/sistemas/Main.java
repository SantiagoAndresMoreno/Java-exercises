package usta.sistemas;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// Author: Santiago Andres Moreno Sanchez
        // Date: 1/04/2020
        // Description: This program calculates the shipping cost of the ten differents products
int p1, p2, p3, p4, p5, destiny;
      Scanner keyboard= new Scanner(System.in);
      f_menu();
      System.out.println("Input the price of the first product");
              p1 = keyboard.nextInt();
        System.out.println("Input the price of the second product");
        p2= keyboard.nextInt();
        System.out.println("Input the price of the third product");
        p3= keyboard.nextInt();
        System.out.println("Input the price of the fourth product");
        p4= keyboard.nextInt();
        System.out.println("Input the price of the fifth product");
        p5=keyboard.nextInt();
        System.out.println("Input the destiny (1= north america) (2=central america) (3= south america) (4= europe) (5=Asia)");
        destiny = keyboard.nextInt();
        int total_bill = p1 + p2 + p3 + p4 + p5 + f_parcel_service(destiny);
        System.out.println("The total bill is: "+total_bill);

    }
    public static void f_menu (){
        // Description: This function show the menu
        System.out.println("----------------------------------------------");
        System.out.println("|                Soft calculate              |");
        System.out.println("|         Version 1.0 2020 april 01          |");
        System.out.println("|         Maker: Santiago Andres Moreno      |");
        System.out.println("----------------------------------------------");
    }
    public static int f_parcel_service (int p_destiny){
        // Description: This software calculates the cost of parcel services
        int valor;
        if (p_destiny==1){
            valor= 11;

        }else if (p_destiny== 2){
            valor = 10;

        }else if (p_destiny== 3){
            valor = 12;

        }else if (p_destiny== 4){
            valor = 24;
        }else if (p_destiny== 5){
            valor = 27;

        }else {
            System.err.println("Error, destiny not found");
            valor = 0;

        }
        return valor;



    }
}
