package usta.sistemas;
import java.lang.annotation.Target;
import java.sql.SQLOutput;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
	// Author: Santiago Andres Moreno Sanchez
        // Date: 26/03/2020
        // Description: This program realize any operation with strings
        Scanner keyboard= new Scanner(System.in);
        String name;
        System.out.println("-------------------------------------------------");
        System.out.println("                    Stringsoft                   ");
        System.out.println("-------------------------------------------------");
        System.out.println("Input your name");
        name = keyboard.nextLine();
        if (name.indexOf("gómez")!= -1) {
            System.out.println("Gómez already exist");


        }else{
            System.out.println("Gómez doesn't exist");
        }
        System.out.println("The upper name is"+name.toUpperCase());
        System.out.println(name.replace( "a","@"));
        System.out.println(name.substring(7));


    }

}