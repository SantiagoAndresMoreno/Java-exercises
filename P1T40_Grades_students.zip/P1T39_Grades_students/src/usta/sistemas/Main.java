package usta.sistemas;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        // Author: Santiago Andres Moreno
        // Date: 24/03/2020
        // Description: This software calculates the final grade of the student
        Scanner keyboard = new Scanner(System.in);
        double grade1, grade2, grade3, grade4, gradeFinal;
        System.out.println("Software GRADESOFT: calculate the final grade");
        System.out.println("Do you need input the first grades (20%)");
        grade1 = keyboard.nextDouble();
        System.out.println("Do you need input the first grades (25%)")
        grade2 = keyboard.nextDouble();
        System.out.println("Do you need input the first grades (25%)")
        grade3 = keyboard.nextDouble();
        System.out.println("Do you need input the first grades (30%)")
        grade4 = keyboard.nextDouble();
        // OR = || y AND =


        if (grade1 < 0 ||grade1 > 5 ||
                grade2<0  || grade2>5 ||
                grade3<0  || grade3>5 ||
                grade4<0  || grade4>5 ||);






    }
}
