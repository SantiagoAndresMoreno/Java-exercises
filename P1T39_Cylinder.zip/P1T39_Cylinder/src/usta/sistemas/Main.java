package usta.sistemas;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// Author: Santiago Andres Moreno Sanchez
        // Date: 19/03/2020
        // Description: This program calculates the volumen of a cylinder
    Scanner keyboard=new Scanner(System.in);
    System.out.println("This program calculate the volumen of a cylinder, input the height (cm):");
    double height, radius, volumen;
    height= keyboard.nextDouble();
    System.out.println("input the radius (cm): ");
    radius= keyboard.nextDouble();
    volumen=3,1415*Math.pow(radius,2)*height;
    System.out.println("the volume of the cylinder is:"+volumen);

    }
}
