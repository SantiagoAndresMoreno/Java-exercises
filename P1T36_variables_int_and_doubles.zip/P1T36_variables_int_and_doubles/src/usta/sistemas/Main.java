package usta.sistemas;

import java.util.Scanner;
public class Main {
    //Author: Santiago Andres Moreno Sanchez
    //Date:12/03/2020
    //Description:This software declare four variables X and Y with int and doubles

    public static void main(String[] args) {
        Scanner keyboard=new Scanner(System.in);
        int x, y;
        double n, m;
        System.out.println(" input the first variable");
        x=keyboard.nextInt();
        System.out.println(" input the second variable");
        y=keyboard.nextInt();
        System.out.println(" input the third variable");
        n=keyboard.nextDouble();
        System.out.println(" input the fourth variable");
        m=keyboard.nextDouble();
        System.out.println("The variables int are: "+x+" and "+y);
        System.out.println("The variables double are: "+n+" and "+m);







    }
}
