package usta.sistemas;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// Author: Santiago Moreno
        //Date: 12/03/2020
        //Description: This software receives two years of birth and print your difference
        Scanner keyboard=new Scanner(System.in);
        int v1, v2, v3 ,difference ;
        System.out.println("Input the first year");
        v1=keyboard.nextInt();
        System.out.println("Input the second year");
        v2=keyboard.nextInt();
        difference=v1-v2;
        System.out.println("The difference of year is: "+difference);

    }
}
