package usta.sistemas;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
	/*AUTHOR: Santiaog Andres Moreno Sanchez
	  DATE: 2020-march-31
	  DESCRIPTION: This software determine the time it takes a person to get from another cycled
	 */
        Scanner keyboard = new Scanner(System.in);
        System.out.println("--------------- soft velocity-----------------");
        System.out.println("║                version: 1.0                 ║");
        System.out.println("║             Created by: Santiago Moreno          ║");
        System.out.println("-----------------------------------------------");
        double velocity;
        System.out.println("Input the constant velocity: (km)");
        velocity = keyboard.nextDouble();

        f_time(velocity);

    }

    public static void f_time(double velocity) {
        /*DESCRIPTION: This fuction calculate the time t:d*v */
        Scanner keyboard = new Scanner(System.in);
        double time, distance;
        System.out.println("Input the distance between into two cities (km)");
        distance = keyboard.nextDouble();
        time = distance / velocity;
        System.out.println("The time is: " + time + "hours");


    }
}