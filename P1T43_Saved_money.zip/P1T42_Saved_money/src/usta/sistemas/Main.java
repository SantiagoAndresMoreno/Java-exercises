package usta.sistemas;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        // Author: Santiago Andres Moreno Sanchez
        // Date: 1/04/2020
        // Description: This program determines how much money a person saves
        Scanner keyboard = new Scanner(System.in);
        f_menu(); //llamo metodo/funcion llamado f_menu();
        System.out.println("input your salary");
        int salary = keyboard.nextInt();
        f_saved_money(salary);
    }


        public static void f_menu (){
            //Description: show the menú
            System.out.println("--------------------------------------");
            System.out.println("|             Softmoney              |");
            System.out.println("|    Version : 1.0 --2020-ap-01      |");
            System.out.println("| Created by: Santiago Andres Moreno |");
            System.out.println("--------------------------------------");

        }
        public static void f_saved_money(int p_salary){
        //description: this method/function calculates the total saved money in a year.
            double saved_money=((p_salary*0.15)*4)*12;
            System.out.println("The total saved money in a year is: "+saved_money);
        }
    }

